<?php echo time(); ?>

<?php echo $content; ?>