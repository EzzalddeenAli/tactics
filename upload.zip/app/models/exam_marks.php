<?php
class exam_marks extends Eloquent {
	public $timestamps = false;
	protected $table = 'exam_marks';
}
