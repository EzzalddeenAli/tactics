<?php
class student_academic_years extends Eloquent {
	public $timestamps = false;
	protected $table = 'student_academic_years';
}
