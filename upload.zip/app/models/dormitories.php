<?php
class dormitories extends Eloquent {
	public $timestamps = false;
	protected $table = 'dormitories';
}