<?php
class class_schedule extends Eloquent {
	public $timestamps = false;
	protected $table = 'class_schedule';
}
