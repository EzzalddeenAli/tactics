<?php
class income extends Eloquent {
	public $timestamps = false;
	protected $table = 'income';
}
