<?php
class assignments extends Eloquent {
	public $timestamps = false;
	protected $table = 'assignments';
}