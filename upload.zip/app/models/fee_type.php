<?php
class fee_type extends Eloquent {
	public $timestamps = false;
	protected $table = 'fee_type';
}
