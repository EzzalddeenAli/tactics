<?php
class assignments_answers extends Eloquent {
	public $timestamps = false;
	protected $table = 'assignments_answers';
}
