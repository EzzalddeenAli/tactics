<?php
class classes extends Eloquent {
	public $timestamps = false;
	protected $table = 'classes';
}