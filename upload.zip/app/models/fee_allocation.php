<?php
class fee_allocation extends Eloquent {
	public $timestamps = false;
	protected $table = 'fee_allocation';
}
