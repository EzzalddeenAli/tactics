<?php
class homeworks extends Eloquent {
	public $timestamps = false;
	protected $table = 'homeworks';
}