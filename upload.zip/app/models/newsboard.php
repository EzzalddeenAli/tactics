<?php
class newsboard extends Eloquent {
	public $timestamps = false;
	protected $table = 'newsboard';
}