<?php
class paymentsCollection extends Eloquent {
	public $timestamps = false;
	protected $table = 'paymentsCollection';
}
